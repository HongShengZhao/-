#ifndef FFT_H
#define FFT_H

#include "StaticRev.h"

float* tmpFloat;

extern int ReverseArrange(float Real[], float Imaginary[], float NewReal[], float NewImaginary[], int Power);
extern int ReverseArrange_Static(float Array[], float NewArray[], int Power);
extern int ReverseArrange_Generator(int Power);

extern int FFT(float TReal[], float TImaginary[], float FReal[], float FImaginary[], int Power);
extern int FFT_Arranged(float Real[], float Imag[], int Power);
extern int FFT_Arranged2(float Real[], float Imag[], float TFRe[], float TFIm[], int Power);
extern int FFT_ArrangedGenerator(int Power);
extern int FFT_Arranged2Generator(int Power);

extern int IFFT(float FReal[], float FImaginary[], float TReal[], float TImaginary[], int Power);
extern int Conj(float Imaginary[], int Amount);

#endif