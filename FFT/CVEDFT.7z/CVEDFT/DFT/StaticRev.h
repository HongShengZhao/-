#ifndef STATICREV_H
#define STATICREV_H

extern void StaticReverseArrange_3(float O[], float N[]);
extern void StaticReverseArrange_4(float O[], float N[]);
extern void StaticRuntimeReverseArrange_3();
extern void StaticReverseArrange_10(float O[], float N[]);

#endif