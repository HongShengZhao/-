#ifndef STATICFFT_5_H
#define STATICFFT_5_H

extern void FFT_Static_5();

#endif