#ifndef STATICFFT_10_H
#define STATICFFT_10_H

extern void FFT_Static_10();

#endif