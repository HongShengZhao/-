#include "FFT.h"
#include <math.h>
#include <stdio.h>
#include <x86intrin.h>
#include <mmintrin.h>
#include <xmmintrin.h>
#include <malloc.h>
#include <unistd.h>

#define diff(a, b) ((a - b) > 0 ? (a - b) : (b - a))
#define IM 0xFFFE0000|
#define RE 0xFFFF0000|
#define SINT 0xFFEF0000|
#define COST 0xFFEE0000|
#define NEWR 0xFFFF0000|
#define OLDR 0xFFFE0000|
#define NEWI 0xFFEF0000|
#define OLDI 0xFFEE0000|

float* tmpFloat;

int ReverseArrange(float Real[], float Imaginary[], float NewReal[], float NewImaginary[], int Power)
{
	ReverseArrange_Static(Real, NewReal, Power);
	ReverseArrange_Static(Imaginary, NewImaginary, Power);
}
int ReverseArrange_Static(float Array[], float NewArray[], int Power)
{
	switch(Power)
	{
		case 3:
			StaticReverseArrange_3(Array, NewArray);
			break;
		case 10:
			StaticReverseArrange_10(Array, NewArray);
			break;
	}
}
int ReverseArrange_Generator(int Power)
{
	int Amount;
	int i, j, irev;
	
	int front, back, shift;
	int odd;

	long sum = 0;
	
	if(Power > 31 || Power < 1)
		return 0;
	Amount = pow(2, Power);
	odd = Power % 2;
	
	for(i = 0;i < Amount;i ++)
	{
		irev = 0;
		for(j = 0;j < Power >> 1;j ++)
		{
			shift = Power - j * 2 - 1;
			front = i & (1 << j);
			back = i & (1 << (Power - j - 1));
			irev |= front << shift;
			irev |= back >> shift;
		}
		if(odd)
		{
			shift = Power >> 1;
			irev |= i & (1 << shift);
		}
		sum += irev;
		printf("\tO[%d] = N[%d];\n", i, irev);
	}
	return 1;
}
int FFT_Init()
{
	int pagesize = sysconf(_SC_PAGE_SIZE);
	tmpFloat = memalign(pagesize, pagesize);
}
int FFT_Exit()
{
	free(tmpFloat);
}
int FFT_Arranged(float Real[], float Imag[], int Power)
{
	int Layer;
	int Half;
	int i, j, k, pmul, p, current, another;
	int Amount, N;
	float ReFactor, ImFactor;
	float Renew, Imnew;
	float TPOA, TPOATP; //TPOA = TwoPiOverAmount, TPOATP = TwoPiOverAmountTimesPmul
	if(Power > 31 || Power < 1)
		return 0;

	__m128 mReFactor, mImFactor, mReal, mImag, m0, m1, m2, m3, mRealC, mImagC;
	float* rsut;
	
	Amount = pow(2, Power);
	Half = pow(2, Power - 1);
	TPOA = 2 * 3.1415926535 / Amount;

	//For each layer in fft.		
	for(Layer = 1;Layer <= Power;Layer ++)
	{
		j = pow(2, Layer - 1);
		N = pow(2, Layer);
		pmul = pow(2, Power - Layer); //W_Amount ^ (0 to p interval j)
		
		for(i = 0;i < pmul;i ++)
		{
			TPOATP = TPOA * pmul;
			{
				//k = 0
				
				ReFactor = 1;
				ImFactor = 0;
				current = i * 2 * j;
				another = current + j;
				
				Renew = Real[current] + Real[another];
				Imnew = Imag[current] + Imag[another];
				Real[another] = Real[current] - Real[another];
				Imag[another] = Imag[current] - Imag[another];
				
				Real[current] = Renew;
				Imag[current] = Imnew;
			}
			{
				for(k = 1;k < j;k ++)
				{
					current = i * 2 * j + k;
					another = current + j;

					if(current % 4 == 0 && k <= j - 4)
					{
						//Aligned
						//0 - 3 : ReFactor
						tmpFloat[0] = cos(TPOATP * (k + 0));
						tmpFloat[1] = cos(TPOATP * (k + 1));
						tmpFloat[2] = cos(TPOATP * (k + 2));
						tmpFloat[3] = cos(TPOATP * (k + 3));
						//4 - 7 : ImFactor
						tmpFloat[4] = - sin(TPOATP * (k + 0));
						tmpFloat[5] = - sin(TPOATP * (k + 1));
						tmpFloat[6] = - sin(TPOATP * (k + 2));
						tmpFloat[7] = - sin(TPOATP * (k + 3));

						//Cos\Sin table generator.
						printf("\t%f, ", tmpFloat[4]);
						printf("%f, ", tmpFloat[5]);
						printf("%f, ", tmpFloat[6]);
						printf("%f, \n", tmpFloat[7]);

						mReFactor = _mm_load_ps(tmpFloat);
						mReal = _mm_load_ps(Real + another);

						m0 = _mm_mul_ps(mReal, mReFactor);
						mImFactor = _mm_load_ps(tmpFloat+ 4);
						mImag = _mm_load_ps(Imag + another);
						m1 = _mm_mul_ps(mImag, mImFactor);
						m2 = _mm_mul_ps(mImag, mReFactor);
						m3 = _mm_mul_ps(mReal, mImFactor);

						mReal = _mm_sub_ps(m0, m1);

						_mm_store_ps(Real + another, mReal);
						mImag = _mm_add_ps(m2, m3);

						mRealC = _mm_load_ps(Real + current);
						mImagC = _mm_load_ps(Imag + current);
						mRealC = _mm_add_ps(mRealC, mReal);
						_mm_store_ps(Imag + another, mImag);
						mImagC = _mm_add_ps(mImagC, mImag);
						_mm_store_ps(Real + current, mRealC);
						_mm_store_ps(Imag + current, mImagC);
						
						k += 3;
					}else
					{
						ReFactor = cos(TPOATP * k);
						ImFactor = - sin(TPOATP * k);

						Renew = Real[another];
						Real[another] = Real[another] * ReFactor - Imag[another] * ImFactor;
						Imag[another] = Imag[another] * ReFactor + Renew * ImFactor;
					
						Real[current] += Real[another];
						Imag[current] += Imag[another];
					}
				}
			}
			for(k = 1;k < 4;k ++)
			{
				if(k == j)
					break;
				Real[N - k + i * N] = Real[k + i * N];
				Imag[N - k + i * N] = - Imag[k + i * N];
			}
			m0 = _mm_setzero_ps();
			for(k = 4;k < j;k ++)
			{
				if(k % 4 == 0 && k <= j - 4)
				{
					mReal = _mm_loadr_ps(Real + k + i * N);
					mImag = _mm_loadr_ps(Imag + k + i * N);
					
					mImag = _mm_sub_ps(m0, mImag);
					_mm_storeu_ps(Real + N - k + i * N - 3, mReal);
					_mm_storeu_ps(Imag + N - k + i * N - 3, mImag);
					
					k += 3;
				}else
				{
					Real[N - k + i * N] = Real[k + i * N];
					Imag[N - k + i * N] = - Imag[k + i * N];
				}
			}
		}
	}
	return 1;
}
int FFT_Arranged2(float Real[], float Imag[], float TFRe[], float TFIm[], int Power)
{
	int Layer;
	int Half;
	int i, k, pmul, p, current, another;
	int Amount;

	Half = pow(2, Power - 1);
	Amount = pow(2, Power);

	for(Layer = 1;Layer <= Power;Layer ++)
	{
		pmul = pow(2, Power - Layer); //W_Amount ^ (0 to p)
		if(Layer % 2 == 1)
		{
			//Real/Imag -> TFRe/TFIm
			for(i = 0;i < Half;i ++)
			{
				p = (i / pmul) * pmul;
				current = i * 2;
				another = i * 2 + 1;
				Real[another] *= cos(2 * 3.1415926535 / Amount * p);
				Imag[another] *= - sin(2 * 3.1415926535 / Amount * p);

				TFRe[i] = Real[current] + Real[another];
				TFIm[i] = Imag[current] + Imag[another];
				TFRe[i + Half] = Real[current] - Real[another];
				TFIm[i + Half] = Imag[current] - Imag[another];
			}
		}else
		{
			//TFRe/TFIm -> Real/Imag
			for(i = 0;i < Half;i ++)
			{
				p = (i / pmul) * pmul;
				current = i * 2;
				another = i * 2 + 1;
				TFRe[another] *= cos(2 * 3.1415926535 / Amount * p);
				TFIm[another] *= - sin(2 * 3.1415926535 / Amount * p);

				Real[i] = TFRe[current] + TFRe[another];
				Imag[i] = TFIm[current] + TFIm[another];
				Real[i + Half] = TFRe[current] - TFRe[another];
				Imag[i + Half] = TFIm[current] - TFIm[another];
			}
		}
	}
	if(Power % 2 == 1)
	{
		//Result is stored in TF
		for(i = 0;i < Amount;i ++)
		{
			Real[i] = TFRe[i];
			Imag[i] = TFIm[i];
		}
	}
	return 1;
}
int FFT_ArrangedGenerator_SSE(int Power)
{	
	int Layer;
	int Half;
	int i, j, k, pmul, current, another;
	int iMul, iAdd;
	int Amount, N;
	int SinCosCount = 0;
	float ReFactor, ImFactor;
	float TPOA, TPOATP;
	float tmp;
	if(Power > 31 || Power < 1)
		return 0;

	Amount = pow(2, Power);
	Half = pow(2, Power - 1);
	TPOA = 2 * 3.1415926535 / Amount;

	iMul = 0; iAdd = 0;
	for(Layer = 1;Layer <= Power;Layer ++)
	{
		j = pow(2, Layer - 1);
		pmul = pow(2, Power - Layer);
		
		for(i = 0;i < pmul;i ++)
		{
			TPOATP = TPOA * pmul;
			N = pow(2, Layer);
			{
				//k = 0
				//FFFF = R, FFFE = I
				//#define P(x) (*(float*)(x))
				//#define A(x) (float*)(x)

				ReFactor = 1;
				ImFactor = 0;
				current = i * 2 * j;
				another = current + j;

				printf("\tTR = P(0x%x) + P(0x%x);\n", RE current, RE another);
				printf("\tTI = P(0x%x) + P(0x%x);\n", IM current, IM another);
				printf("\tP(0x%x) = P(0x%x) - P(0x%x);\n", RE another, RE current, RE another);
				printf("\tP(0x%x) = P(0x%x) - P(0x%x);\n", IM another, IM current, IM another);
				printf("\tP(0x%x) = TR; P(0x%x) = TI;\n", RE current, IM current);
			}
			for(k = 1;k < j;k ++)
			{
				current = i * 2 * j + k;
				another = current + j;

				if(current % 4 == 0 && k <= j - 4)
				{
					//Aligned
					
					//printf("\tmRF = _mm_load_ps(&FFT_Static_10_Cos[%d]);\n", SinCosCount);
					//printf("\tmIF = _mm_load_ps(&FFT_Static_10_Sin[%d]);\n", SinCosCount);
					printf("\tmRF = _mm_load_ps(A(0x%x));\n", COST SinCosCount);
					printf("\tmIF = _mm_load_ps(A(0x%x));\n", SINT SinCosCount);
					SinCosCount += 4;

					printf("\tmRL = _mm_load_ps(A(0x%x));\n", RE another);
					printf("\tmIL = _mm_load_ps(A(0x%x));\n", IM another);
					
					printf("\tmR = mRL;\n");
					printf("\tmI = mIL;\n");

					printf("\tm0 = _mm_mul_ps(mR, mRF);\n");
					printf("\tm1 = _mm_mul_ps(mI, mIF);\n");
					printf("\tm2 = _mm_mul_ps(mI, mRF);\n");
					printf("\tm3 = _mm_mul_ps(mR, mIF);\n");
					
					printf("\tmR = _mm_sub_ps(m0, m1);\n");
					printf("\tmI = _mm_add_ps(m2, m3);\n");

					printf("\t_mm_store_ps(A(0x%x), mR);\n", RE another);
					printf("\t_mm_store_ps(A(0x%x), mI);\n", IM another);

					printf("\tmRC = _mm_load_ps(A(0x%x));\n", RE current);
					printf("\tmIC = _mm_load_ps(A(0x%x));\n", IM current);
					printf("\tmRC = _mm_add_ps(mRC, mR);\n");
					printf("\tmIC = _mm_add_ps(mIC, mI);\n");
					printf("\t_mm_store_ps(A(0x%x), mRC);\n", RE current);
					printf("\t_mm_store_ps(A(0x%x), mIC);\n", IM current);
					
					k += 3;
				}else
				{
					ReFactor = cos(TPOATP * k);
					ImFactor = - sin(TPOATP * k);

					if(! (diff(ImFactor, 0) < 0.00001 && diff(ReFactor, 1) < 0.00001))
					{
						printf("\tTR = P(0x%x);\n", RE another);
						printf("\tP(0x%x) = ", RE another);
						if(diff(ReFactor, 0) > 0.00001)
						{
							if(diff(ReFactor, 1) > 0.00001)
								printf("P(0x%x) * %f", RE another, ReFactor);
							else
								printf("P(0x%x)", RE another);
						}
						if(diff(ImFactor, 0) > 0.00001)
						{
							if(diff(ImFactor, 1) > 0.00001)
							{
								if(ImFactor > 0)
								{
									printf(" - ");
									printf("P(0x%x) * %f", IM another, ImFactor);
								}else
								{
									printf(" + ");
									if(diff(-ImFactor, 1) > 0.00001)
										printf("P(0x%x) * %f", IM another, - ImFactor);
									else
										printf("P(0x%x)", IM another);
								}
							}
							else
							{
								printf(" - ");
								printf("P(0x%x)", IM another);
							}
						}
						printf(";\n");


						printf("\tP(0x%x) = ", IM another);
						if(diff(ReFactor, 0) > 0.00001)
						{
							if(diff(ReFactor, 1) > 0.00001)
								printf("P(0x%x) * %f", IM another, ReFactor);
							else
								printf("P(0x%x)", IM another);
						}
						if(diff(ImFactor, 1) > 0.00001)
						{
							if(ImFactor != 1)
							{
								if(ImFactor > 0)
								{
									printf(" + ");
									printf("TR * %f", ImFactor);
								}else
								{
									printf(" - ");
									if(diff(- ImFactor, 1) < 0.00001)
										printf("TR");
									else
										printf("TR * %f", - ImFactor);
								}
							}else
							{
								printf(" + ");
								printf("TR");
							}
						}
						printf(";\n");
					}
					printf("\tP(0x%x) += P(0x%x); P(0x%x) += P(0x%x);\n", RE current, RE another, IM current, IM another);
				}
			}
			for(k = 1;k < 4;k ++)
			{
				if(k == j)
					break;
				printf("\tP(0x%x) = P(0x%x);", RE (N - k + i * N), RE (k + i * N));
				printf(" P(0x%x) = - P(0x%x);\n", IM (N - k + i * N), IM (k + i * N));
			}
			if(k < j)
			{
				printf("\tm0 = _mm_setzero_ps();\n");
				for(k = 4;k < j;k ++)
				{
					if(k % 4 == 0 && k <= j - 4)
					{
						printf("\tmR = _mm_loadr_ps(A(0x%x));\n", RE (k + i * N));
						printf("\tmI = _mm_loadr_ps(A(0x%x));\n", IM (k + i * N));

						printf("\tmI = _mm_sub_ps(m0, mI);\n");
						printf("\t_mm_storeu_ps(A(0x%x), mR);\n", RE (N - k + i * N - 3));
						printf("\t_mm_storeu_ps(A(0x%x), mI);\n", IM (N - k + i * N - 3));
						
						k += 3;
					}else
					{
						printf("\tP(0x%x) = P(0x%x);", RE (N - k + i * N), RE (k + i * N));
						printf(" P(0x%x) = - P(0x%x);\n", IM (N - k + i * N), IM (k + i * N));
					}
				}
			}
		}
	}
	return 1;
}
int FFT_ArrangedGenerator(int Power)
{	
	int Layer;
	int Half;
	int i, j, k, pmul, current, another;
	int iMul, iAdd;
	int Amount, N;
	float ReFactor, ImFactor;
	float TPOA, TPOATP;
	if(Power > 31 || Power < 1)
		return 0;

	Amount = pow(2, Power);
	Half = pow(2, Power - 1);
	TPOA = 2 * 3.1415926535 / Amount;

	iMul = 0; iAdd = 0;
	for(Layer = 1;Layer <= Power;Layer ++)
	{
		j = pow(2, Layer - 1);
		pmul = pow(2, Power - Layer);
		
		for(i = 0;i < pmul;i ++)
		{
			TPOATP = TPOA * pmul;
			N = pow(2, Layer);
			{
				//k = 0
				//FFFF = R, FFFE = I
				//#define P(x) (*(float*)(x))

				ReFactor = 1;
				ImFactor = 0;
				current = i * 2 * j;
				another = current + j;

				printf("\tTR = P(0x%x) + P(0x%x);\n", RE current, RE another);
				printf("\tTI = P(0x%x) + P(0x%x);\n", IM current, IM another);
				printf("\tP(0x%x) = P(0x%x) - P(0x%x);\n", RE another, RE current, RE another);
				printf("\tP(0x%x) = P(0x%x) - P(0x%x);\n", IM another, IM current, IM another);
				printf("\tP(0x%x) = TR; P(0x%x) = TI;\n", RE current, IM current);
				iAdd += 2;
			}
			for(k = 1;k < j;k ++)
			{
				ReFactor = cos(TPOATP * k);
				ImFactor = - sin(TPOATP * k);
				current = i * 2 * j + k;
				another = current + j;

				if(! (diff(ImFactor, 0) < 0.00001 && diff(ReFactor, 1) < 0.00001))
				{
					iMul ++;
					
					printf("\tTR = P(0x%x);\n", RE another);
					printf("\tP(0x%x) = ", RE another);
					if(diff(ReFactor, 0) > 0.00001)
					{
						if(diff(ReFactor, 1) > 0.00001)
							printf("P(0x%x) * %f", RE another, ReFactor);
						else
							printf("P(0x%x)", RE another);
					}
					if(diff(ImFactor, 0) > 0.00001)
					{
						if(diff(ImFactor, 1) > 0.00001)
						{
							if(ImFactor > 0)
							{
								printf(" - ");
								printf("P(0x%x) * %f", IM another, ImFactor);
							}else
							{
								printf(" + ");
								if(diff(-ImFactor, 1) > 0.00001)
									printf("P(0x%x) * %f", IM another, - ImFactor);
								else
									printf("P(0x%x)", IM another);
							}
						}
						else
						{
							printf(" - ");
							printf("P(0x%x)", IM another);
						}
					}
					printf(";\n");


					printf("\tP(0x%x) = ", IM another);
					if(diff(ReFactor, 0) > 0.00001)
					{
						if(diff(ReFactor, 1) > 0.00001)
							printf("P(0x%x) * %f", IM another, ReFactor);
						else
							printf("P(0x%x)", IM another);
					}
					if(diff(ImFactor, 1) > 0.00001)
					{
						if(ImFactor != 1)
						{
							if(ImFactor > 0)
							{
								printf(" + ");
								printf("TR * %f", ImFactor);
							}else
							{
								printf(" - ");
								if(diff(- ImFactor, 1) < 0.00001)
									printf("TR");
								else
									printf("TR * %f", - ImFactor);
							}
						}else
						{
							printf(" + ");
							printf("TR");
						}
					}
					printf(";\n");
				}

				iAdd += 2;
				printf("\tP(0x%x) += P(0x%x); P(0x%x) += P(0x%x);\n", RE current, RE another, IM current, IM another);
			}
			for(k = 1;k < j;k ++)
			{
				printf("\tP(0x%x) = P(0x%x);", RE (N - k + i * N), RE (k + i * N));
				printf(" P(0x%x) = - P(0x%x);\n", IM (N - k + i * N), IM (k + i * N));
			}
		}
	}
	printf("Mul: %d, Add: %d", iMul, iAdd);
	return 1;
}
int FFT_Arranged2Generator(int Power)
{
	int Layer;
	int Half;
	int i, k, pmul, p, current, another;
	int Amount;
	float ReFactor, ImFactor;

	Half = pow(2, Power - 1);
	Amount = pow(2, Power);

	for(Layer = 1;Layer <= Power;Layer ++)
	{
		pmul = pow(2, Power - Layer); //W_Amount ^ (0 to p)
		if(Layer % 2 == 1)
		{
			//Real/Imag -> TFRe/TFIm
			for(i = 0;i < Half;i ++)
			{
				p = (i / pmul) * pmul;
				current = i * 2;
				another = i * 2 + 1;
				ReFactor = cos(2 * 3.1415926535 / Amount * p);
				ImFactor = - sin(2 * 3.1415926535 / Amount * p);
				
				if(ReFactor != 1)
					if(ReFactor >= 0.00001 || ReFactor <= -0.00001)
						printf("\tR[%d] *= %f;", another, ReFactor);
					else
						printf("\tR[%d] = 0.0f;", another);
				if(ImFactor != 1)
				{
					if(ImFactor >= 0.00001 || ImFactor <= -0.00001)
						printf("\tI[%d] *= %f;", another, ImFactor);
					else
						printf("\tI[%d] = 0.0f;", another);
					printf("\n");
				}
				
				//Real[another] *= ReFactor;
				//Imag[another] *= ImFactor;

				printf("\tTR[%d] = R[%d] + R[%d];\n", i, current, another);
				printf("\tTI[%d] = I[%d] + I[%d];\n", i, current, another);
				printf("\tTR[%d] = R[%d] - R[%d];\n", i + Half, current, another);
				printf("\tTI[%d] = I[%d] - I[%d];\n", i + Half, current, another);
				
				//TFRe[i] = Real[current] + Real[another];
				//TFIm[i] = Imag[current] + Imag[another];
				//TFRe[i + Half] = Real[current] - Real[another];
				//TFIm[i + Half] = Imag[current] - Imag[another];
			}
		}else
		{
			//TFRe/TFIm -> Real/Imag
			for(i = 0;i < Half;i ++)
			{
				p = (i / pmul) * pmul;
				current = i * 2;
				another = i * 2 + 1;
				ReFactor = cos(2 * 3.1415926535 / Amount * p);
				ImFactor = - sin(2 * 3.1415926535 / Amount * p);
				
				if(ReFactor != 1)
					if(ReFactor >= 0.00001 || ReFactor <= -0.00001)
						printf("\tTR[%d] *= %f;", another, ReFactor);
					else
						printf("\tTR[%d] = 0.0f;", another);
				if(ImFactor != 1)
				{
					if(ImFactor >= 0.00001 || ImFactor <= -0.00001)
						printf("\tTI[%d] *= %f;", another, ImFactor);
					else
						printf("\tTI[%d] = 0.0f;", another);
					printf("\n");
				}
				
				//TFRe[another] *= cos(2 * 3.1415926535 / Amount * p);
				//TFIm[another] *= - sin(2 * 3.1415926535 / Amount * p);

				printf("\tR[%d] = TR[%d] + TR[%d];\n", i, current, another);
				printf("\tI[%d] = TI[%d] + TI[%d];\n", i, current, another);
				printf("\tR[%d] = TR[%d] - TR[%d];\n", i + Half, current, another);
				printf("\tI[%d] = TI[%d] - TI[%d];\n", i + Half, current, another);
				
				//Real[i] = TFRe[current] + TFRe[another];
				//Imag[i] = TFIm[current] + TFIm[another];
				//Real[i + Half] = TFRe[current] - TFRe[another];
				//Imag[i + Half] = TFIm[current] - TFIm[another];
			}
		}
	}
	if(Power % 2 == 1)
	{
		//Result is stored in TF
		for(i = 0;i < Amount;i ++)
		{
			printf("\tR[i] = TR[i];", i, i);
			printf("\tI[i] = TI[i];\n", i, i);
			//Real[i] = TFRe[i];
			//Imag[i] = TFIm[i];
		}
	}
	return 1;
}